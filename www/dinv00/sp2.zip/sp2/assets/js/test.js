/*
<div class="result">
                    <h4>food</h4>
                    <img class="food-img" src="" alt="">
                    <button type="button" class="read-more-btn">Read more</button>
                </div>
                */

//example GET

/*
"https://api.edamam.com/search?q=chicken&
app_id=97a604a5&
app_key=ccaae9e03961a7202ed70438e0261d28&
&from=0&to=3&calories=591-722&health=alcohol-free
*/
